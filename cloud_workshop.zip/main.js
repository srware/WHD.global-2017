/*jslint node:true, vars:true, bitwise:true, unparam:true */
/*jshint unused:true */
// Leave the above lines for propper jshinting
//Type Node.js Here :)

var groveSensor = require('jsupm_grove');
var mraa = require('mraa');
console.log('MRAA Version: ' + mraa.getVersion());

// UDP socket
var dgram = require('dgram');
var client = dgram.createSocket('udp4');
var server = dgram.createSocket("udp4");

// UDP Options
var options = {
    host : '127.0.0.1',
    port : 41234
};

// Create the button object using D2
var resetButton = new groveSensor.GroveButton(2);

// Create the light sensor object using AIO pin 0
var light = new groveSensor.GroveLight(0);

// Load LCD module on I2C
var LCD = require('jsupm_i2clcd');
var myLcd = new LCD.Jhd1313m1 (0, 0x3E, 0x62);
var flash = false;

// Fault variable
var fault = false;

// Lux fault threshold
var luxThreshold = 10;

function loop() {
    // Read lux value from sensor
    var lux = light.value();
    console.log("Light Sensor: " + lux + " lux");
    
    // Send lux value to the cloud
    sendObservation("light", lux, new Date().getTime());
    
    // Check for fault
    if(lux < luxThreshold && !fault) {
        fault = true;
    }
    
    // Clear LCD
    myLcd.clear();
    
    // If no fault has been detected write lux value to lcd
    if(!fault) {
        myLcd.setColor(0,255,0);
        myLcd.setCursor(0,0);
        myLcd.write('Light: ' + lux + ' lux');
        myLcd.setCursor(1,0);
        myLcd.write('No faults');
    } else {
        flash = !flash;      
        if(flash) {
            myLcd.setColor(255,0,0);
        } else {
            myLcd.setColor(0,0,0);
        }
        
        myLcd.setCursor(0,0);
        myLcd.write('     Fault      ');
        myLcd.setCursor(1,0);
        myLcd.write('    Detected    ');
    }
}
setInterval(loop, 2000);

// Read the reset button value to manually reset after a fault
function readResetButton() {
    // If reet button is pushed set our fault variable back to false
    if(resetButton.value()) {
        fault = false;
    }
}
setInterval(readResetButton, 1000);

// Send sensor data to the cloud
function sendObservation(name, value, on) {
    var msg = JSON.stringify({
        n: name,
        v: value,
        on: on
    });

    var sentMsg = new Buffer(msg);
    console.log("Sending observation: " + sentMsg);
    client.send(sentMsg, 0, sentMsg.length, options.port, options.host);
}

// Listen for actions from the cloud
server.on("error", function (err) {
    console.log("Server error:\n" + err.stack);
    server.close();
});

server.on("message", function (msg, rinfo) {
    // Ignore essages unless they are from local agent
    if(rinfo.address != "127.0.0.1") {
        return;
    }

    // Parse message from the cloud
    var js = JSON.parse(msg);
    var component = js['component'];
    var command = js['command'];
    var argvArray = js['argv'];

    for(var i = 0; i < argvArray.length; i++) {
        var name = argvArray[i]['name'];
        var value = argvArray[i]['value'];

        // Handle fault reset
        if (name == "fault") {
            if(value == "0") {
                fault = false;
            } else if(value == "1") {
                fault = true;
            }
        }
    }
});

server.on("listening", function () {
  var address = server.address();
  console.log("Server listening on " +
      address.address + ":" + address.port);
});

server.bind(41235);