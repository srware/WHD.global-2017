module.exports = {
	auth: require('./auth'),
	control: require('./control'),
	data: require('./data')
};